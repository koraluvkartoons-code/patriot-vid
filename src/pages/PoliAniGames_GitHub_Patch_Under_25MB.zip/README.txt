POLIANIGAMES GITHUB PATCH

This package contains the modified PoliAniGames.tsx supplied in this chat.

What changed:
- Keeps the existing PoliAniGames data loading, categories, search, sorting and PostCard flow.
- Adds a MAP -> VIDEO toggle.
- MAP mode keeps the existing World Map / Globe / Dressing components.
- VIDEO mode turns the map panel into a terminal-style animated post feed.
- The video-style panel displays the currently loaded PoliAniGames posts over the map-feed interface.
- No other site components were included or intentionally redesigned because only PoliAniGames.tsx was supplied.

IMPORTANT:
The uploaded source was a single TSX file, not the complete GitHub repository. Put this file at the same path as your existing PoliAniGames.tsx in the project and keep the rest of your repository unchanged.
