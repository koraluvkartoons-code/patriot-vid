export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      banned_ips: {
        Row: {
          created_at: string
          expires_at: string
          id: string
          ip_address: string
          reason: string | null
          stream_id: string | null
        }
        Insert: {
          created_at?: string
          expires_at: string
          id?: string
          ip_address: string
          reason?: string | null
          stream_id?: string | null
        }
        Update: {
          created_at?: string
          expires_at?: string
          id?: string
          ip_address?: string
          reason?: string | null
          stream_id?: string | null
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          created_at: string
          guest_name: string
          guest_session_id: string
          id: string
          is_deleted: boolean
          media_type: string | null
          media_url: string | null
          reply_to: string | null
          stream_id: string
          text: string | null
        }
        Insert: {
          created_at?: string
          guest_name: string
          guest_session_id: string
          id?: string
          is_deleted?: boolean
          media_type?: string | null
          media_url?: string | null
          reply_to?: string | null
          stream_id: string
          text?: string | null
        }
        Update: {
          created_at?: string
          guest_name?: string
          guest_session_id?: string
          id?: string
          is_deleted?: boolean
          media_type?: string | null
          media_url?: string | null
          reply_to?: string | null
          stream_id?: string
          text?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_stream_id_fkey"
            columns: ["stream_id"]
            isOneToOne: false
            referencedRelation: "streams"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_timeouts: {
        Row: {
          created_at: string
          expires_at: string
          guest_session_id: string
          id: string
          stream_id: string | null
        }
        Insert: {
          created_at?: string
          expires_at: string
          guest_session_id: string
          id?: string
          stream_id?: string | null
        }
        Update: {
          created_at?: string
          expires_at?: string
          guest_session_id?: string
          id?: string
          stream_id?: string | null
        }
        Relationships: []
      }
      comments: {
        Row: {
          created_at: string
          edited_at: string | null
          id: string
          is_archived: boolean
          media_type: string | null
          media_url: string | null
          post_id: string
          text: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          edited_at?: string | null
          id?: string
          is_archived?: boolean
          media_type?: string | null
          media_url?: string | null
          post_id: string
          text?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          edited_at?: string | null
          id?: string
          is_archived?: boolean
          media_type?: string | null
          media_url?: string | null
          post_id?: string
          text?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      posts: {
        Row: {
          category: string | null
          created_at: string
          description: string | null
          id: string
          is_archived: boolean
          is_pinned: boolean
          likes: string[] | null
          media: Json
          media_type: string | null
          media_url: string | null
          scheduled_at: string | null
          site: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_archived?: boolean
          is_pinned?: boolean
          likes?: string[] | null
          media?: Json
          media_type?: string | null
          media_url?: string | null
          scheduled_at?: string | null
          site?: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          category?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_archived?: boolean
          is_pinned?: boolean
          likes?: string[] | null
          media?: Json
          media_type?: string | null
          media_url?: string | null
          scheduled_at?: string | null
          site?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar: string | null
          badges: string[] | null
          created_at: string
          display_name: string
          id: string
          is_admin: boolean | null
          is_moderator: boolean | null
        }
        Insert: {
          avatar?: string | null
          badges?: string[] | null
          created_at?: string
          display_name: string
          id?: string
          is_admin?: boolean | null
          is_moderator?: boolean | null
        }
        Update: {
          avatar?: string | null
          badges?: string[] | null
          created_at?: string
          display_name?: string
          id?: string
          is_admin?: boolean | null
          is_moderator?: boolean | null
        }
        Relationships: []
      }
      reposts: {
        Row: {
          created_at: string
          id: string
          media: Json
          post_id: string
          quote_text: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          media?: Json
          post_id: string
          quote_text?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          media?: Json
          post_id?: string
          quote_text?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reposts_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      streams: {
        Row: {
          created_at: string
          duration_seconds: number | null
          ended_at: string | null
          host_user_id: string
          id: string
          recording_url: string | null
          room_name: string
          screen_recording_url: string | null
          segments: Json
          started_at: string
          status: string
          thumbnail_url: string | null
          title: string
          viewer_count: number | null
        }
        Insert: {
          created_at?: string
          duration_seconds?: number | null
          ended_at?: string | null
          host_user_id: string
          id?: string
          recording_url?: string | null
          room_name: string
          screen_recording_url?: string | null
          segments?: Json
          started_at?: string
          status?: string
          thumbnail_url?: string | null
          title?: string
          viewer_count?: number | null
        }
        Update: {
          created_at?: string
          duration_seconds?: number | null
          ended_at?: string | null
          host_user_id?: string
          id?: string
          recording_url?: string | null
          room_name?: string
          screen_recording_url?: string | null
          segments?: Json
          started_at?: string
          status?: string
          thumbnail_url?: string | null
          title?: string
          viewer_count?: number | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
