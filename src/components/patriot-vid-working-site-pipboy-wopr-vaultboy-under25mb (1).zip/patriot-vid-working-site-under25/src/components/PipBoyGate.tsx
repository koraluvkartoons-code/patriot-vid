import { useEffect, useRef, useState } from "react";
import { LockKeyhole, RotateCcw } from "lucide-react";
import vaultBoy from "@/assets/vault-boy-full.png";

type Props = { unlocked: boolean; onUnlock: () => void };

const POSES = [
  { label: "THUMBS UP", arm: "pose-thumbs-up" },
  { label: "READY", arm: "pose-ready" },
  { label: "COMMAND", arm: "pose-command" },
  { label: "ALERT", arm: "pose-alert" },
];

export default function PipBoyGate({ unlocked, onUnlock }: Props) {
  const [code, setCode] = useState("");
  const [pose, setPose] = useState(0);
  const [error, setError] = useState("");
  const codeRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Enter" && !unlocked) verify();
      if (e.key === "Escape") setCode("");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const verify = () => {
    if (code === "1984") {
      setError("");
      onUnlock();
    } else {
      setError("ACCESS DENIED // INVALID VAULT CODE");
      setCode("");
      codeRef.current?.focus();
    }
  };

  if (unlocked) return null;

  return (
    <section className="pipboy-gate" aria-label="Pip-Boy protected feed">
      <div className="pipboy-gate-screen">
        <div className="pipboy-gate-header">
          <span>VAULT-TEC PIP-BOY 3000</span>
          <span>SECURE FEED</span>
        </div>

        <button
          type="button"
          className={`pipboy-figure-wrap ${POSES[pose].arm}`}
          onClick={() => codeRef.current?.focus()}
          aria-label="Pip-Boy. Press to enter vault code."
        >
          <img
            src={vaultBoy}
            alt="Vault Boy giving a thumbs-up"
            className="pipboy-figure-image"
            draggable={false}
          />
        </button>

        <div className="pipboy-pose-row">
          <button type="button" onClick={() => setPose((pose + POSES.length - 1) % POSES.length)} aria-label="Previous Pip-Boy display">◀</button>
          <span>{POSES[pose].label} // DISPLAY {pose + 1}/4</span>
          <button type="button" onClick={() => setPose((pose + 1) % POSES.length)} aria-label="Next Pip-Boy display">▶</button>
        </div>

        <div className="pipboy-lock-copy">
          <LockKeyhole className="w-4 h-4" />
          <div>
            <strong>MAIN FEED LOCKED</strong>
            <small>PRESS PIP-BOY OR ENTER CODE TO DISPLAY POSTS</small>
          </div>
        </div>

        <div className="pipboy-code-row">
          <input
            ref={codeRef}
            autoFocus
            inputMode="numeric"
            maxLength={4}
            value={code}
            onChange={(e) => { setError(""); setCode(e.target.value.replace(/\D/g, "")); }}
            placeholder="••••"
            aria-label="Vault code"
          />
          <button type="button" onClick={verify}>UNLOCK</button>
        </div>
        {error && <p className="pipboy-error">{error}</p>}
        <p className="pipboy-hint">D-PAD / BUTTONS CONTROL DISPLAY • VAULT CODE REQUIRED FOR POSTS</p>
      </div>
    </section>
  );
}

export function PipBoyMiniControl() {
  return (
    <span className="pipboy-mini" title="Pip-Boy control">
      <RotateCcw className="w-3 h-3" />
    </span>
  );
}
