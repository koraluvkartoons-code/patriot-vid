import { ChangeEvent, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase";

type SettePost = {
  id: string;
  title: string;
  body: string | null;
  media_url: string | null;
  media_type: string | null;
  created_at: string;
};

type SetteProps = {
  channelId?: string;
};

export default function Sette({ channelId = "main" }: SetteProps) {
  const [artwork, setArtwork] = useState("");
  const [cassetteColor, setCassetteColor] = useState("#32134d");
  const [name, setName] = useState("MY SETTE");
  const [posts, setPosts] = useState<SettePost[]>([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [uploading, setUploading] = useState(false);
  const artworkInput = useRef<HTMLInputElement>(null);
  const mediaInput = useRef<HTMLInputElement>(null);

  async function loadPosts() {
    const { data } = await supabase
      .from("sette_posts")
      .select("*")
      .eq("channel_id", channelId)
      .order("created_at", { ascending: false });
    if (data) setPosts(data);
  }

  useEffect(() => {
    loadPosts();
    const channel = supabase
      .channel(`sette-${channelId}`)
      .on("postgres_changes", {
        event: "*",
        schema: "public",
        table: "sette_posts",
        filter: `channel_id=eq.${channelId}`,
      }, loadPosts)
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [channelId]);

  function readArtwork(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setArtwork(String(reader.result));
    reader.readAsDataURL(file);
  }

  async function addMediaPost(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const path = `sette/${crypto.randomUUID()}-${file.name}`;
      const upload = await supabase.storage.from("media").upload(path, file);
      if (upload.error) throw upload.error;
      const { data } = supabase.storage.from("media").getPublicUrl(path);
      const mediaType = file.type.startsWith("video/") ? "video" : "image";
      const { error } = await supabase.from("sette_posts").insert({
        channel_id: channelId,
        title: title || file.name,
        body: body || null,
        media_url: data.publicUrl,
        media_type: mediaType,
      });
      if (error) throw error;
      setTitle(""); setBody("");
      if (mediaInput.current) mediaInput.current.value = "";
    } catch (err) {
      console.error(err);
      alert("Upload failed. Check your Supabase storage setup.");
    } finally {
      setUploading(false);
    }
  }

  async function addTextPost() {
    if (!body.trim()) return;
    const { error } = await supabase.from("sette_posts").insert({
      channel_id: channelId,
      title: title || "SETTE POST",
      body,
      media_url: null,
      media_type: "text",
    });
    if (error) alert(error.message);
    else { setTitle(""); setBody(""); }
  }

  return (
    <main className="min-h-screen bg-[#09040e] text-white px-4 py-10">
      <div className="mx-auto max-w-6xl">
        <header className="text-center mb-10">
          <p className="text-xs tracking-[.45em] text-purple-300">PATRIOT.VID</p>
          <h1 className="text-5xl font-black tracking-[.2em] text-purple-100">SETTE</h1>
          <p className="text-purple-300 mt-2">CASSETTE MEDIA PLAYER</p>
        </header>

        <section className="rounded-3xl border border-purple-900 bg-[#120819] p-5 sm:p-8 mb-10">
          <div className="grid lg:grid-cols-[1fr_360px] gap-8">
            <div>
              <input value={name} onChange={e => setName(e.target.value)}
                className="w-full rounded-xl bg-black/40 border border-purple-800 p-3 mb-4"
                placeholder="Cassette name" />
              <div className="flex flex-wrap gap-3 mb-5">
                <button onClick={() => artworkInput.current?.click()}
                  className="rounded-xl bg-purple-700 px-4 py-3 font-bold">
                  ADD CASSETTE PHOTO
                </button>
                <input ref={artworkInput} hidden type="file" accept="image/*" onChange={readArtwork} />
                <label className="rounded-xl border border-purple-800 p-3 flex items-center gap-3">
                  COLOR
                  <input type="color" value={cassetteColor}
                    onChange={e => setCassetteColor(e.target.value)} />
                </label>
              </div>

              <div className="relative aspect-[1.75] rounded-[28px] overflow-hidden border-4 border-black"
                style={{ background: cassetteColor, boxShadow: `0 0 35px ${cassetteColor}99` }}>
                {artwork && <img src={artwork} alt="" className="absolute inset-0 w-full h-full object-cover opacity-80" />}
                <div className="absolute inset-[15%_9%] rounded-xl border-2 border-black/60 bg-black/30">
                  <div className="absolute left-[15%] right-[15%] top-1/2 h-8 -translate-y-1/2 rounded-full bg-black/80" />
                </div>
                <span className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-black/70 px-4 py-1 text-xs font-black tracking-widest">
                  {name}
                </span>
              </div>
            </div>

            <div className="rounded-2xl bg-black/30 border border-purple-900 p-5">
              <h2 className="font-black text-xl mb-4">ADD MEDIA</h2>
              <input value={title} onChange={e => setTitle(e.target.value)}
                className="w-full rounded-xl bg-black/50 border border-purple-800 p-3 mb-3"
                placeholder="Post title" />
              <textarea value={body} onChange={e => setBody(e.target.value)}
                className="w-full rounded-xl bg-black/50 border border-purple-800 p-3 mb-3"
                rows={5} placeholder="Post text..." />
              <input ref={mediaInput} type="file" accept="image/*,video/*"
                onChange={addMediaPost} disabled={uploading}
                className="w-full text-sm mb-3" />
              <button onClick={addTextPost}
                className="w-full rounded-xl bg-purple-700 p-3 font-black">
                {uploading ? "UPLOADING..." : "ADD TEXT POST"}
              </button>
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-3xl font-black mb-6">ALL SETTE POSTS</h2>
          {posts.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-purple-800 p-12 text-center text-purple-300">
              No SETTE posts yet.
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-7">
              {posts.map(post => (
                <article key={post.id} className="overflow-hidden rounded-3xl border border-purple-900 bg-[#120819]">
                  <div className="relative aspect-[1.7] overflow-hidden" style={{ background: cassetteColor }}>
                    {post.media_type === "video" && post.media_url ? (
                      <video src={post.media_url} autoPlay muted loop playsInline controls className="w-full h-full object-cover" />
                    ) : post.media_type === "image" && post.media_url ? (
                      <img src={post.media_url} alt={post.title} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center p-6 text-center">
                        <p>{post.body}</p>
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <div className="text-xs text-purple-400 font-bold">SETTE • {post.media_type}</div>
                    <h3 className="font-black mt-1">{post.title}</h3>
                    {post.media_type !== "text" && post.body && <p className="text-sm text-purple-200 mt-2">{post.body}</p>}
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
