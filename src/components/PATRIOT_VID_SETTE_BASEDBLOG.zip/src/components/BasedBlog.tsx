import { ChangeEvent, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase";

type BlogPost = {
  id: string;
  title: string;
  body: string;
  media_url: string | null;
  published_at: string | null;
  scheduled_for: string | null;
  created_at: string;
};

export default function BasedBlog() {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [publishMode, setPublishMode] = useState<"now" | "schedule">("now");
  const [scheduledFor, setScheduledFor] = useState("");
  const [mediaUrl, setMediaUrl] = useState("");

  async function load() {
    const { data } = await supabase
      .from("basedblog_posts")
      .select("*")
      .lte("published_at", new Date().toISOString())
      .order("published_at", { ascending: false });
    if (data) setPosts(data);
  }

  useEffect(() => {
    load();
    const channel = supabase.channel("basedblog-live")
      .on("postgres_changes", {
        event: "*", schema: "public", table: "basedblog_posts"
      }, load)
      .subscribe();
    const timer = window.setInterval(load, 15000);
    return () => {
      window.clearInterval(timer);
      supabase.removeChannel(channel);
    };
  }, []);

  async function publish() {
    if (!title.trim() || !body.trim()) return;
    const now = new Date().toISOString();
    const scheduled = publishMode === "schedule" && scheduledFor
      ? new Date(scheduledFor).toISOString()
      : now;

    const { error } = await supabase.from("basedblog_posts").insert({
      title,
      body,
      media_url: mediaUrl || null,
      published_at: scheduled,
      scheduled_for: publishMode === "schedule" ? scheduled : null,
    });

    if (error) alert(error.message);
    else {
      setTitle(""); setBody(""); setMediaUrl(""); setScheduledFor("");
      await load();
    }
  }

  return (
    <main className="min-h-screen bg-[#07040b] text-white px-4 py-10">
      <div className="mx-auto max-w-5xl">
        <header className="mb-8">
          <p className="text-xs tracking-[.45em] text-purple-400">PATRIOT.VID</p>
          <h1 className="text-4xl sm:text-6xl font-black">BASEDBLOG</h1>
          <p className="text-purple-300 mt-2">LIVE NEWS • LIVEBLOGGING • SCHEDULED UPDATES</p>
        </header>

        <section className="rounded-3xl border border-purple-900 bg-[#120819] p-5 mb-10">
          <h2 className="text-2xl font-black mb-5">PUBLISH UPDATE</h2>
          <input value={title} onChange={e => setTitle(e.target.value)}
            className="w-full rounded-xl bg-black/40 border border-purple-800 p-3 mb-3"
            placeholder="Headline" />
          <textarea value={body} onChange={e => setBody(e.target.value)}
            className="w-full rounded-xl bg-black/40 border border-purple-800 p-3 mb-3"
            rows={7} placeholder="Live news update..." />
          <input value={mediaUrl} onChange={e => setMediaUrl(e.target.value)}
            className="w-full rounded-xl bg-black/40 border border-purple-800 p-3 mb-4"
            placeholder="Optional image/video URL" />

          <div className="flex flex-wrap gap-3 items-center">
            <select value={publishMode} onChange={e => setPublishMode(e.target.value as "now" | "schedule")}
              className="rounded-xl bg-black border border-purple-800 p-3">
              <option value="now">Publish now</option>
              <option value="schedule">Schedule</option>
            </select>

            {publishMode === "schedule" && (
              <input type="datetime-local" value={scheduledFor}
                onChange={e => setScheduledFor(e.target.value)}
                className="rounded-xl bg-black border border-purple-800 p-3" />
            )}

            <button onClick={publish}
              className="rounded-xl bg-purple-700 px-6 py-3 font-black">
              {publishMode === "now" ? "PUBLISH LIVE" : "SCHEDULE UPDATE"}
            </button>
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-black">LIVE FEED</h2>
            <span className="text-xs text-green-400">● LIVE</span>
          </div>

          <div className="space-y-5">
            {posts.map(post => (
              <article key={post.id} className="rounded-3xl border border-purple-900 bg-[#120819] p-5">
                <div className="text-xs text-purple-400 mb-2">
                  {new Date(post.published_at || post.created_at).toLocaleString()}
                </div>
                <h3 className="text-2xl font-black">{post.title}</h3>
                <p className="whitespace-pre-wrap mt-3 text-purple-100">{post.body}</p>
                {post.media_url && (
                  <a href={post.media_url} target="_blank" rel="noreferrer"
                    className="inline-block mt-4 text-purple-300 underline">
                    Open attached media
                  </a>
                )}
              </article>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
