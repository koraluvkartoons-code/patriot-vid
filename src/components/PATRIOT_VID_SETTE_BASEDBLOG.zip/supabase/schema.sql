-- BASEDBLOG + SETTE shared backend
create extension if not exists pgcrypto;

create table if not exists public.basedblog_posts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  media_url text,
  published_at timestamptz not null default now(),
  scheduled_for timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.sette_posts (
  id uuid primary key default gen_random_uuid(),
  channel_id text not null default 'main',
  title text not null,
  body text,
  media_url text,
  media_type text not null default 'text',
  created_at timestamptz not null default now()
);

alter table public.basedblog_posts enable row level security;
alter table public.sette_posts enable row level security;

-- Public read access for published BASEDBLOG posts and SETTE posts.
create policy "basedblog public read"
on public.basedblog_posts for select
using (published_at <= now());

create policy "sette public read"
on public.sette_posts for select
using (true);

-- Simple public posting policies.
-- IMPORTANT: replace these with authenticated/admin policies before using this publicly.
create policy "basedblog public insert"
on public.basedblog_posts for insert
with check (true);

create policy "sette public insert"
on public.sette_posts for insert
with check (true);

-- Storage bucket for SETTE media.
insert into storage.buckets (id, name, public)
values ('media', 'media', true)
on conflict (id) do nothing;

create policy "media public read"
on storage.objects for select
using (bucket_id = 'media');

create policy "media public upload"
on storage.objects for insert
with check (bucket_id = 'media');

-- Realtime
alter publication supabase_realtime add table public.basedblog_posts;
alter publication supabase_realtime add table public.sette_posts;
