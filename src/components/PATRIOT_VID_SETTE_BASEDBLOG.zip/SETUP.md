# PATRIOT.VID — SETTE + BASEDBLOG

This package adds two React/TypeScript sections:

- SETTE: custom cassette artwork, cassette color picker, shared photo/video/text posts, realtime refresh, autoplay muted video.
- BASEDBLOG: live news feed, realtime updates, scheduled posts, headline/body/media URL.

## 1. Supabase

Create a Supabase project and run `supabase/schema.sql` in the SQL Editor.

Create your environment variables in the Lovable project's `.env`:

VITE_SUPABASE_URL=YOUR_SUPABASE_PROJECT_URL
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY

Do NOT put a Supabase service-role key in the browser.

## 2. Dependency

The project needs:

npm install @supabase/supabase-js

If Lovable already has Supabase installed, do not install it again.

## 3. Files

Copy:
src/integrations/supabase.ts
src/components/Sette.tsx
src/components/BasedBlog.tsx

into the matching folders in your project.

## 4. Add to a page

Import:

import Sette from "@/components/Sette";
import BasedBlog from "@/components/BasedBlog";

Then render:

<Sette />
<BasedBlog />

Use separate routes/pages if preferred.

## 5. Scheduling

BASEDBLOG stores `published_at`. The feed only displays posts whose published_at is now or earlier.

The UI also polls every 15 seconds and listens for Supabase Realtime changes.

For a production-grade scheduled publishing system, use a trusted server/Edge Function/cron to publish or process scheduled jobs. The browser should not be trusted as an admin.

## 6. Security warning

The included SQL allows public inserts so the demo works immediately. Before public launch, add authentication and restrict publishing to your admin account. Otherwise visitors can create BASEDBLOG and SETTE posts.

## 7. Existing PipBoyGate

This package does NOT replace or modify PipBoyGate.tsx. Keep your restored working version.

## 8. Important upload limitation

SETTE cassette artwork is currently previewed in the browser. SETTE media posts are uploaded to Supabase Storage and are shared through the database. The cassette artwork itself can be made persistent too by uploading it to the storage bucket and saving its URL in a dedicated channel/settings table.
